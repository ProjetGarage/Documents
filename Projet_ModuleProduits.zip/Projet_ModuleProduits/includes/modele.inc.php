<?php
require_once("connexion.inc.php");
class produitsModele{
	private $requete;
	private $params;
	private $connexion;
	
function __construct($requete=null,$params=null){
		$this->requete=$requete;
		$this->params=$params;
}
	
function obtenirConnexion(){
	$maConnexion = new Connexion("localhost", "root", "", "bdgaragevirtuel");
	$maConnexion->connecter();
	return $maConnexion->getConnexion();
}

function executer(){
		$this->connexion = $this->obtenirConnexion();
		$stmt = $this->connexion->prepare($this->requete);
		$stmt->execute($this->params);
		$this->deconnecter();
		return $stmt;		
	}
function deconnecter(){
		unset($this->connexion);
}
	
	
function verserFichier($dossier, $inputNom,$chaine){
	$dossier="../$dossier/";
	$nomProduit=sha1($chaine.time());
	if($_FILES[$inputNom]['tmp_name']!==""){
		//Upload de la photo
		$fichier= $_FILES[$inputNom]['name'];
		$extension=strrchr($fichier,'.');
		@move_uploaded_file($tmp,$dossier.$nomProduit.$extension);
		$photoProd=$nomProduit.$extension;
	}
	return $photoProd;
}
function enleverFichier($dossier,$photoProd){
		$rmPoc="../$dossier/".$photoProd;
		$tabFichiers = glob("../$dossier/*");
		//print_r($tabFichiers);
		// parcourir les fichier
		foreach($tabFichiers as $fichier){
		  if(is_file($fichier) && $fichier==trim($rmPoc)) {
			// enlever le fichier
			unlink($fichier);
			break;
		  }
		}
	
}	
}//fin de la classe
?>