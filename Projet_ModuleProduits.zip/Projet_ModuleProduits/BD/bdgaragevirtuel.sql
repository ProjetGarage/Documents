DROP DATABASE bdgaragevirtuel;
CREATE DATABASE bdgaragevirtuel;
USE bdgaragevirtuel;

DROP TABLE IF EXISTS Connexions;
DROP TABLE IF EXISTS Membres;
DROP TABLE IF EXISTS Adresses;
DROP TABLE IF EXISTS Produits;
DROP TABLE IF EXISTS PhotoProduits;
DROP TABLE IF EXISTS Categories;
DROP TABLE IF EXISTS Vendeurs;
DROP TABLE IF EXISTS Abonnements;
DROP TABLE IF EXISTS Evenements;

CREATE TABLE Connexions (
 idMembre  INT(8) NOT NULL AUTO_INCREMENT,
 courriel  VARCHAR(35) NOT NULL,
 motPasse  VARCHAR(100) NOT NULL,
 CONSTRAINT Connexions_FK FOREIGN KEY (idMembre) REFERENCES Membres(idMembre));

CREATE TABLE Membres (
 idMembre      INT(8) NOT NULL AUTO_INCREMENT,    
 prenom        VARCHAR(35) NOT NULL,
 nom           VARCHAR(35) NoT NULL,
 telephone     VARCHAR(12) NOT NULL,
 dateNaissance DATE NOT NULL,
 sexe          VARCHAR(1) NOT NULL,
 photoMembre   VARCHAR(255) NOT NULL,
 CONSTRAINT Membres_PK PRIMARY KEY (idMembre));
 
 INSERT INTO Membres VALUES (0,'Faye', 'Sharabyani', '514-723-2777','1985-09-13', 'F', '');
 INSERT INTO Membres VALUES (0,'Julie','Tremblay', '438-897-8500','1976-04-22', 'F', '');
 INSERT INTO Membres VALUES (0,'Antonio','Tavares', '514-332-7654','1965-02-14', 'M', '');
 
CREATE TABLE Adresses (
 idAdresse     INT(8) NOT NULL AUTO_INCREMENT,
 idMembre      INT(8) NOT NULL,  
 numeroCivique VARCHAR(5)  NOT NULL,
 nomRue        VARCHAR(30) NoT NULL,
 ville         VARCHAR(30) NOT NULL,
 codePostal    VARCHAR(7)  NOT NULL,
 region        VARCHAR(50) NOT NULL,
 latitude      DECIMAL(18,9)  NOT NULL,
 longitude     DECIMAL(18,9)  NOT NULL,
 CONSTRAINT Adresses_PK PRIMARY KEY (idAdresse),
 CONSTRAINT Adresses_FK FOREIGN KEY (idMembre) REFERENCES Membres(idMembre));

 INSERT INTO Adresses VALUES (0,1, 5365, 'Av du Parc', 'Montreal', 'H2V 4G9','Montreal',0.0,0.0);
 
 
CREATE TABLE Produits (
 idProduit    INT(8) NOT NULL AUTO_INCREMENT,
 nomProduit   VARCHAR(50) NOT NULL,
 description  TEXT NOT NULL,
 quantite     INT(5) NOT NULL,
 idCategorie  INT(8) NOT NULL,
 idMembre     INT(8) NOT NULL,
 CONSTRAINT Produits_PK PRIMARY KEY (idProduit),
 CONSTRAINT Produits_FK_idMembre    FOREIGN KEY (idMembre)      REFERENCES Vendeurs(idMembre),
 CONSTRAINT Produits_FK_idProduit   FOREIGN KEY (idProduit)     REFERENCES PhotoProduits(idProduit) ON DELETE CASCADE,
 CONSTRAINT Produits_FK_idCategorie FOREIGN KEY (idCategorie)   REFERENCES Categories(idCategorie));
 
  ALTER TABLE Produits
  MODIFY idProduit int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;
 
 INSERT INTO Produits VALUES (0,'bouteille allaitement playtex','Plusieurs biberons en etat neuf',4,5,1);
 
CREATE TABLE PhotoProduits (
 idPhoto     INT(8) NOT NULL AUTO_INCREMENT,
 idProduit   INT(8) NOT NULL,
 photoProd   VARCHAR(255) NOT NULL,
 CONSTRAINT PhotoProduits_PK PRIMARY KEY (idPhoto),
 CONSTRAINT PhotoProduits_FK_idProduit   FOREIGN KEY (idProduit)   REFERENCES Produits(idProduit) ON DELETE CASCADE,
 CONSTRAINT PhotoProduits_FK_idEvenement FOREIGN KEY (idEvenement) REFERENCES Evenements(idEvenement));
 
 ALTER TABLE PhotoProduits
  MODIFY idPhoto int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;
 
 INSERT INTO PhotoProduits VALUES (0,1,1,'dc46011423fdcdb6d27c46f0358f491c.jpg');

CREATE TABLE Categories (
 idCategorie  INT(8) NOT NULL AUTO_INCREMENT,
 nomCategorie VARCHAR(50) NOT NULL,
 CONSTRAINT Categories_PK PRIMARY KEY (idCategorie));
 
 INSERT INTO Categories VALUES (0,'Accessoires Informatiques');
 INSERT INTO Categories VALUES (0,'Appareils electromenagers');
 INSERT INTO Categories VALUES (0,'Appareils photo et cameras');
 INSERT INTO Categories VALUES (0,'Art et objet de collection');
 INSERT INTO Categories VALUES (0,'Articles pour bebes et enfants');
 INSERT INTO Categories VALUES (0,'Articles de sport et exercice');
 INSERT INTO Categories VALUES (0,'Autre');
 INSERT INTO Categories VALUES (0,'Bijoux et montres');
 INSERT INTO Categories VALUES (0,'Equipements electroniques');
 INSERT INTO Categories VALUES (0,'Instruments de musique');
 INSERT INTO Categories VALUES (0,'Objets gratuits');
 INSERT INTO Categories VALUES (0,'Sante et beaute');
 INSERT INTO Categories VALUES (0,'Souliers');
 INSERT INTO Categories VALUES (0,'velos');
 INSERT INTO Categories VALUES (0,'vetements');
 INSERT INTO Categories VALUES (0,'Sacs a main et portefeuilles');
 
CREATE TABLE Vendeurs (
 idMembre     INT(8) NOT NULL AUTO_INCREMENT,
 idAbonnement INT(8) NOT NULL,
 idAdresse    INT(8) NOT NULL,
 idEvenement  INT(8) NOT NULL,
 idProduit    INT(8) NOT NULL,
 actif        INT(1) NOT NULL,
 CONSTRAINT Vendeurs_FK_idMembre     FOREIGN KEY (idMembre)      REFERENCES Membres(idMembre),
 CONSTRAINT Vendeurs_FK_idAbonnement FOREIGN KEY (idAbonnement)  REFERENCES Abonnements(idAbonnement),
 CONSTRAINT Vendeurs_FK_idAdresse    FOREIGN KEY (idAdresse)     REFERENCES Adresses(idAdresses),
 CONSTRAINT Vendeurs_FK_idEvenement  FOREIGN KEY (idEvenement)   REFERENCES Evenements(idEvenement)ON DELETE CASCADE,
 CONSTRAINT Vendeurs_FK_idProduit    FOREIGN KEY (idProduit)     REFERENCES Produits(idProduit) ON DELETE CASCADE);
 
 INSERT INTO Vendeurs VALUES (1,1,1,1,1,1);
 INSERT INTO Vendeurs VALUES (1,1,1,1,2,1);
 INSERT INTO Vendeurs VALUES (1,1,1,1,3,1);
 INSERT INTO Vendeurs VALUES (1,1,1,1,4,1);
 INSERT INTO Vendeurs VALUES (2,1,2,2,5,1);
 INSERT INTO Vendeurs VALUES (3,1,3,3,6,1);
 
CREATE TABLE Abonnements (
 idAbonnement    INT(8) NOT NULL AUTO_INCREMENT,
 typeAbonnement  VARCHAR(8) NOT NULL,
 prix            DECIMAL(5,2),        
 CONSTRAINT Abonnements_PK PRIMARY KEY (idAbonnement)); 
 
 INSERT INTO Abonnements VALUES (0,'Regulier',0.00);
 INSERT INTO Abonnements VALUES (0,'Plus', 9.99);
 
 ALTER TABLE Abonnements
  MODIFY idAbonnement int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;
 
 
 CREATE TABLE Evenements (
 idEvenement    INT(8) NOT NULL AUTO_INCREMENT,
 titreEvenement VARCHAR(150) NOT NULL,
 description    VARCHAR(255) NOT NULL,
 idAdresse      INT(8) NOT NULL,
 dateDebut      DATETIME NOT NULL,
 dateFin        DATETIME NOT NULL,
 CONSTRAINT Evenements_PK PRIMARY KEY (idEvenement),
 CONSTRAINT Evenements_FK FOREIGN KEY (idAdresse) REFERENCES Adresses(idAdresse));
