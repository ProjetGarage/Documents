<?php
	require("../includes/modele.inc.php");
	$tabRes=array();
	
	function remplirListeCategories()
	{
		global $tabRes;	
		$tabRes['action']="listeC";
		 try{
			$requete="SELECT * FROM categories";
			$unModele=new produitsModele($requete,array());
			$stmt=$unModele->executer();
			$tabRes['listeCat']=array();
			while($ligne=$stmt->fetch(PDO::FETCH_OBJ)){
			    $tabRes['listeCat'][]=$ligne;
			 }
		}catch(Exception $e){
		}finally{
			unset($unModele);
		}
		
	}
	
	function remplirListeVendeurs()
	{
		global $tabRes;	
		$tabRes['action']="listeV";
		 try{
			$requete="select DISTINCT Vendeurs.idMembre, Membres.nom, Membres.prenom from Vendeurs, Membres where Vendeurs.idMembre=Membres.idMembre ORDER BY Membres.prenom";	
			$unModele=new produitsModele($requete,array());
			$stmt=$unModele->executer();
			$tabRes['listeVen']=array();
			while($ligne=$stmt->fetch(PDO::FETCH_OBJ)){
			    $tabRes['listeVen'][]=$ligne;
			 }
			 
		}catch(Exception $e){
		}finally{
			unset($unModele);
		}
		
	}
	
	function lister()
	{
		global $tabRes;
		$tabRes['action']="listeP";
		try{
			 $requete="select nomProduit, description, quantite from produits";
			 $unModele=new produitsModele($requete,array());
			 $stmt=$unModele->executer();
			 $tabRes['listeProd']=array();
			 while($ligne=$stmt->fetch(PDO::FETCH_OBJ)){
			    $tabRes['listeProd'][]=$ligne;
			}
		}catch(Exception $e){
		}finally{
			unset($unModele);
		}
	}
	
	
	function listerProduitsVendeur()
	{
		global $tabRes;
		$numVendeur=$_POST['vendeur2'];
		$tabRes['action']="listeProduits";
		
		try{
			 $requete="select nomProduit, description, quantite from produits where produits.idMembre=?";
			 $unModele=new produitsModele($requete,array($numVendeur));
			 $stmt=$unModele->executer();
			 $tabRes['listePr']=array();
			 while($ligne=$stmt->fetch(PDO::FETCH_OBJ)){
			    $tabRes['listePr'][]=$ligne;
			}
		}catch(Exception $e){
		}finally{
			unset($unModele);
		}
	}
	
	
	
	function listerC()
	{
		global $tabRes;
		$tabRes['action']="listeCat";
		try{
			 $requete="select nomCategorie, nomProduit, description, quantite from produits, categories where produits.idCategorie = categories.idCategorie ORDER BY categories.nomCategorie" ;
			 $unModele=new produitsModele($requete,array());
			 $stmt=$unModele->executer();
			 $tabRes['listePC']=array();
			 while($ligne=$stmt->fetch(PDO::FETCH_OBJ)){
			    $tabRes['listePC'][]=$ligne;
			}
		}catch(Exception $e){
		}finally{
			unset($unModele);
		}
	}
	
	function enregistrer(){
		global $tabRes;	
		$produit=$_POST['nomProduit'];
	    $idCategorie=$_POST['categorie'];
	    $idMembre=$_POST['vendeur'];
	    $quantite=$_POST['quantite'];
	    $description=$_POST['description'];
			
		try{
			$unModele=new produitsModele();
			$photoProd=$unModele->verserFichier("images", "photoProd",$produit);
			$requete1="INSERT INTO Produits VALUES(0,?,?,?,?,?)";
			$unModele=new produitsModele($requete1,array($produit,$description,$quantite,$idCategorie,$idMembre));
			$stmt=$unModele->executer();
			$requete2="SELECT MAX(idProduit) AS LastID FROM Produits";
			$unModele=new produitsModele($requete2,array());
			$stmt=$unModele->executer();
			if($ligne=$stmt->fetch(PDO::FETCH_OBJ))
			    $idp=$ligne->LastID;
			
			$requete3="INSERT INTO Photoproduits VALUES(0,?,?)";
			$unModele=new produitsModele($requete3,array($idp,$photoProd));
			$stmt=$unModele->executer();
			$tabRes['action']="enregistrer";
			$tabRes['msg']="produit bien enregistre";
		}catch(Exception $e){
		}finally{
			unset($unModele);
		}
	}
	
	
		
	//******************************************************
	//Contr�leur
	$action=$_POST['action'];
	switch($action){
		case "enregistrer" :
		     enregistrer();
		break;
		
        case "listeP" :
			lister();
		break;
		
		case "listeCat" :
			listerC();
		break;
		
		case "listeC" :
			remplirListeCategories();
		break;
		
		case "listeV" :
			remplirListeVendeurs();
		break;
		
		case "listeProduits" :
			listerProduitsVendeur();
		break;
	}
    echo json_encode($tabRes);
?>