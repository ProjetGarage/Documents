//vue voyages

function listerCategories(list){
	var taille;
	var rep;
	taille=list.length;
	
	for(var i=0; i<taille; i++){
		rep+="<option value=" + list[i].idCategorie + " " + list[i].nomCategorie + ">" + list[i].idCategorie + " " + list[i].nomCategorie + "</option>";
	}
	
	$('#categorie').html(rep);
}

function listerV(list){
	var taille;
	var rep, numero;
	taille=list.length;
	for(var i=0; i<taille; i++){
		rep+="<option value=" + list[i].idMembre + " " + list[i].prenom + " " + list[i].nom + ">" + list[i].idMembre + " " + list[i].prenom + " " + list[i].nom + "</option>";
		
	}
	
	$('#vendeur').html(rep);
	$('#vendeur2').html(rep);
	
}

function listerP(list){
	var taille;
	var rep="<div class='table-users' style='overflow: scroll; height: 500px;'>";
	rep+="<div class='header'>Liste des produits<span style='float:right;padding-right:10px;cursor:pointer;' onClick=\"$('#contenu').hide();\">X</span></div>";
	rep+="<table cellspacing='0'>";
	rep+="<tr><th>NOM PRODUIT</th><th>DESCRIPTION</th><th>QUANTITE</th></tr>";

	taille=list.length;
	for(var i=0; i<taille; i++){
		rep+="<tr><td>"+list[i].nomProduit+"</td><td>"+list[i].description+"</td><td>"+list[i].quantite+"</td></tr>";		 
	}
	rep+="</table>";
	rep+="</div>";
	$('#contenu').html(rep);
}

function listerCat(list){
	var taille;
	var rep="<div class='table-users' style='overflow: scroll; height: 500px;'>";
	rep+="<div class='header'>Lister les produits par categorie <span style='float:right;padding-right:10px;cursor:pointer;' onClick=\"$('#contenu').hide();\">X</span></div>";
	rep+="<table cellspacing='0'>";
	rep+="<tr><th>CATEGORIE</th><th>NOM PRODUIT</th><th>DESCRIPTION</th><th>QUANTITE</th></tr>";

	taille=list.length;
	for(var i=0; i<taille; i++){
		rep+="<tr><td>"+list[i].nomCategorie+"</td><td>"+list[i].nomProduit+"</td><td>"+list[i].description+"</td><td>"+list[i].quantite+"</td></tr>";		 
	}
	rep+="</table>";
	rep+="</div>";
	$('#contenu').html(rep);
}


function listerProduits(list){
	var taille;
	var rep="<div class='table-users' style='overflow: scroll; height: 500px;'>";
	rep+="<div class='header'>Lister les produits par vendeur <span style='float:right;padding-right:10px;cursor:pointer;' onClick=\"$('#contenu').hide();\">X</span></div>";
	rep+="<table cellspacing='0'>";
	rep+="<tr><th>NOM PRODUIT</th><th>DESCRIPTION</th><th>QUANTITE</th></tr>";

	taille=list.length;
	for(var i=0; i<taille; i++){
		rep+="<tr><td>"+list[i].nomProduit+"</td><td>"+list[i].description+"</td><td>"+list[i].quantite+"</td></tr>";		 
	}
	rep+="</table>";
	rep+="</div>";
	
	$('#contenu').html(rep);
}

var produitsVue=function(reponse){
	var action=reponse.action; 
	switch(action){
		case "enregistrer" :
			$('#messages').html(reponse.msg);
			setTimeout(function(){ $('#messages').html(""); }, 10000);
		break;
		
		case "listeCat" :
			listerCat(reponse.listePC);
		break;
				
		case "listeP" :
			listerP(reponse.listeProd);
		break;
		
		case "listeC" :
			listerCategories(reponse.listeCat);
		break;
		
		case "listeV" :
			listerV(reponse.listeVen);
		break;
		
		
		case "listeProduits":
		     listerProduits(reponse.listePr);
		break;
		
	}
}

