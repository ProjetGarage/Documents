//requ�tes produits

function listerProduitsVendeur()
{
	var formProduit = new FormData(document.getElementById('formLister'));
	formProduit.append('action','listeProduits');
	$.ajax({
		type : 'POST',
		url :  'Produits/produitsControleur.php',
		data : formProduit,
		dataType : 'json', //text pour le voir en format de string
		contentType : false,
		processData : false,
		success : function (reponse){//alert(reponse);
					produitsVue(reponse);
		},
		fail : function (err){
		   
		}
	});	

}

function lister() {
	var formProduit = new FormData();
	formProduit.append('action','listeP');
	$.ajax({
		type : 'POST',
		url :  'Produits/produitsControleur.php',
		data : formProduit,
		dataType : 'json', //text pour le voir en format de string
		contentType : false,
		processData : false,
		success : function (reponse){//alert(reponse);
					produitsVue(reponse);
		},
		fail : function (err){
		   
		}
	});
	
}

function listerC() {
	var formProduit = new FormData();
	formProduit.append('action','listeCat');//alert(formFilm.get("action"));
	$.ajax({
		type : 'POST',
		url :  'Produits/produitsControleur.php',
		data : formProduit,
		dataType : 'json', //text pour le voir en format de string
		contentType : false,
		processData : false,
		success : function (reponse){//alert(reponse);
					produitsVue(reponse);
		},
		fail : function (err){
		   
		}
	});
	
}

function enregistrer(){
	var formProduit = new FormData(document.getElementById('formEnreg'));
	formProduit.append('action','enregistrer');
	$.ajax({
		type :'POST',
		url : 'Produits/produitsControleur.php',
		data : formProduit,
		dataType : 'json', //text pour le voir en format de string
		contentType : false,
		processData : false,
		success : function (reponse){//alert(reponse);
					produitsVue(reponse);
		},
		fail : function (err){
		   
		}
	});
}

function remplirListeCategories() {
	var formProduit = new FormData();
	formProduit.append('action','listeC');//alert(formFilm.get("action"));
	$.ajax({
		type : 'POST',
		url :  'Produits/produitsControleur.php',
		data : formProduit,
		dataType : 'json', //text pour le voir en format de string
		contentType : false,
		processData : false,
		success : function (reponse){//alert(reponse);
					produitsVue(reponse);
		},
		fail : function (err){
		   
		}
	});
	
}
	
function remplirListeVendeurs() {
	var formProduit = new FormData();
	formProduit.append('action','listeV');//alert(formFilm.get("action"));
	$.ajax({
		type : 'POST',
		url :  'Produits/produitsControleur.php',
		data : formProduit,
		dataType : 'json', //text pour le voir en format de string
		contentType : false,
		processData : false,
		success : function (reponse){//alert(reponse);
					produitsVue(reponse);
		},
		fail : function (err){
		   
		}
	});
	
}	
